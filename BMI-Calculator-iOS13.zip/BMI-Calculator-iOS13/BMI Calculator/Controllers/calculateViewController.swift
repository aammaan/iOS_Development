//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Angela Yu on 21/08/2019.
//  Copyright © 2019 Angela Yu. All rights reserved.
//

import UIKit

class calculateViewController: UIViewController {

    @IBOutlet weak var heightLabel: UILabel!
    
    @IBOutlet weak var heightView: UISlider!
    @IBOutlet weak var weightLabel: UILabel!
    
    var calculatorbrain = calculatorBrain()
    
    @IBOutlet weak var weightView: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func heightSlider(_ sender: UISlider) {
        heightLabel.text=String(format: "%.2f", sender.value) + "m"
    }
    
    @IBAction func weightSlider(_ sender: UISlider) {
        weightLabel.text=String(Int(sender.value)) + "Kg"
    }
    
    @IBAction func calculatePressed(_ sender: UIButton) {
        calculatorbrain.calculateBMI(height: Float(heightView.value), weight: Float(weightView.value))        
        self.performSegue(withIdentifier: "goToResult", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToResult" {
            let destinationVC = segue.destination as! resultViewController
            var check = calculatorbrain.getBMIValue()
            destinationVC.bmiValue = String(check)
            destinationVC.advice=calculatorbrain.getAdvice()
            destinationVC.color=calculatorbrain.getColor()
            

        }
    }
    
    
}

