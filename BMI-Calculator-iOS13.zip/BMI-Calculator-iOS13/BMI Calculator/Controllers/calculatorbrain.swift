//
//  CalculatorBrain.swift
//  BMI Calculator
//
//  Created by Aman Sharma on 30/05/23.
//  Copyright © 2023 Angela Yu. All rights reserved.
//

import UIKit

struct calculatorBrain {
    var bmi: BMI?
    mutating func calculateBMI(height: Float,weight: Float){
        
       let  check =  weight/pow(height, 2)
        if check < 18.5 {
            bmi=BMI(value: check, advice: "Eat more pies", color: UIColor.blue)
        }else if check <= 24.9 && check >= 18.5 {
            bmi=BMI(value: check, advice: "Fit as a field", color: UIColor.green)
        }else{
            bmi=BMI(value: check, advice: "Eat less pies", color: UIColor.red)
        }
       
        
    }
    func getBMIValue() ->Float {
      
        let bmito1Decimal = Float( bmi?.value ?? 0.0)
            return bmito1Decimal
       
    }
    func getAdvice() ->String{
        return bmi?.advice ?? "blank"
    }
    
    func getColor() -> UIColor {
        return bmi?.color ?? UIColor.white
    }
}
