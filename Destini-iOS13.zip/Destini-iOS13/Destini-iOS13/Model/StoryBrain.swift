//
//  StoryBrain.swift
//  Destini-iOS13
//
//  Created by Angela Yu on 08/08/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import Foundation

struct storyBrain{
    // In this array we are creating the struct at every element. Like 1st element is made with help of struct of Story, and similarly every element is like that.
    
    let story = [
        Story(
            title: "You wake up in a mysterious room with no windows and only one door. There are three buttons in front of you labeled 'Red'and 'Blue' ",
            choice1: "Press the red button.",
            choice1Destination: 1,
            choice2: "Press the blue button.",
            choice2Destination: 2
           
        ),
       

        Story(
            title: "As soon as you press the red button, an alarm blares and the room starts filling with water. Panic sets in as you realize it's a trap!",
            choice1: "Look for an emergency exit.",
            choice1Destination: 4,
            choice2: "Try to break the door down.",
            choice2Destination: 5
        ),
        Story(
            title: "Pressing the blue button triggers a series of flashing lights and a loud siren. Suddenly, a robotic voice announces that you have won a prize!",
            choice1: "Search the room for the prize.",
            choice1Destination: 6,
            choice2: "Exit the room through the door.",
            choice2Destination: 7
        ),
        Story(
            title: "When you press the green button, the room starts to spin rapidly. You feel dizzy and disoriented.",
            choice1: "Hold onto something to stabilize yourself.",
            choice1Destination: 8,
            choice2: "Close your eyes and wait for it to stop.",
            choice2Destination: 9
        ),
        Story(
            title: "You frantically search the room for an emergency exit, but there's none to be found. The water level keeps rising.",
            choice1: "Take a deep breath and swim to the top.",
            choice1Destination: 10,
            choice2: "Look for any objects that can help you.",
            choice2Destination: 11
        ),
        Story(
            title: "You gather all your strength and start kicking the door, but it won't budge. Time is running out.",
            choice1: "Look around for any tools or objects to aid you.",
            choice1Destination: 11,
            choice2: "Yell for help at the top of your lungs.",
            choice2Destination: 12
        ),
        Story(
            title: "You search every corner of the room and finally find a small key hidden behind a painting. It unlocks the door.",
            choice1: "Proceed through the unlocked door.",
            choice1Destination: 7,
            choice2: "Stay in the room and investigate further.",
            choice2Destination: 13
        ),
        Story(
            title: "As you step out of the room, you find yourself in a grand hall filled with cheering people. They congratulate you on winning a million dollars!",
            choice1: "Accept the prize and celebrate.",
            choice1Destination: 14,
            choice2: "Question the reality of the situation.",
            choice2Destination: 15
        ),
        Story(
            title: "You grab onto a nearby chair to steady yourself. The spinning gradually slows down, and the room comes to a halt.",
            choice1: "Catch your breath and assess the situation.",
            choice1Destination: 16,
            choice2: "Exit the room through the now-stationary door.",
            choice2Destination: 7
        ),
        Story(
            title: "You close your eyes tightly and wait for the spinning sensation to subside. When you open your eyes, everything is still.",
            choice1: "Take a moment to regain your balance.",
            choice1Destination: 16,
            choice2: "Proceed through the door cautiously.",
            choice2Destination: 17
        ),
        Story(
            title: "You find yourself in a dark corridor with multiple doors. Each door has a different symbol engraved on it.",
            choice1: "Open the door with a star symbol.",
            choice1Destination: 16,
            choice2: "Open the door with a moon symbol.",
            choice2Destination: 3
        ),
        Story(
            title: "You swim upward with all your strength, desperately trying to reach the surface. Just when you feel like you can't hold your breath any longer, you break through the water and gasp for air.",
            choice1: "Take a moment to catch your breath and assess your surroundings.",
            choice1Destination: 8,
            choice2: "Look for any signs of civilization.",
            choice2Destination: 10
        ),
        Story(
            title: "Amidst your desperate search, you come across a rusty pipe lying in the corner. It might be useful for breaking down the door.",
            choice1: "Grab the rusty pipe and attempt to break down the door.",
            choice1Destination: 4,
            choice2: "Continue searching for any other useful objects.",
            choice2Destination: 9
        ),
        Story(
            title: "You scream at the top of your lungs, hoping someone will hear you and come to your rescue. However, the only response you hear is the echo of your own voice.",
            choice1: "Try to remain calm and think of another solution.",
            choice1Destination: 7,
            choice2: "Keep shouting for help.",
            choice2Destination: 17
        ),
        Story(
            title: "As you explore the room further, you discover a hidden compartment behind a bookshelf. Inside, you find a diary with cryptic writings.",
            choice1: "Read the diary and try to decipher its meaning.",
            choice1Destination: 14,
            choice2: "Leave the diary behind and continue exploring.",
            choice2Destination: 12
        ),
        Story(
            title: "You accept the prize graciously and join the celebration. However, a nagging feeling of unease lingers in the back of your mind.",
            choice1: "Enjoy the moment and immerse yourself in the celebration.",
            choice1Destination: 13,
            choice2: "Investigate further to uncover the truth behind the prize.",
            choice2Destination: 15
        ),
        Story(
            title: "You question the reality of the situation, wondering if this is all just an elaborate illusion. Doubt creeps in as you contemplate your next move.",
            choice1: "Interact with the people around you to gather more information.",
            choice1Destination: 5,
            choice2: "Seek a way to test the authenticity of your surroundings.",
            choice2Destination: 8
        ),
        Story(
            title: "After catching your breath, you realize you have entered a dimly lit chamber with peculiar symbols adorning the walls. The atmosphere feels mysterious and ancient.",
            choice1: "Examine the symbols closely to decipher their meaning.",
            choice1Destination: 13,
            choice2: "Proceed cautiously through the chamber.",
            choice2Destination: 16
        ),
        Story(
            title: "You open the door with a star symbol and find yourself in a celestial observatory. The room is filled with telescopes and star charts, sparking your curiosity about the universe.",
            choice1: "Take a closer look at the telescopes and star charts.",
            choice1Destination: 11,
            choice2: "Search for any clues or hidden compartments.",
            choice2Destination: 18
        )
    ]

    // Continue adding more stories to complete the narrative.
    
    
}

