//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var player: AVAudioPlayer!

    @IBOutlet weak var textView: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    let dict: [String : Int] = ["Soft" : 5, "Medium" : 7*60, "Hard" : 12*60]
    var hardness : Int = 0
    var timer = Timer()
    var progress:Float = 0
    var down:Float=0
    
    @IBAction func hardnessSelectionButton(_ sender: UIButton) {
        timer.invalidate()
        textView.text = sender.currentTitle!
        
        progress = 0
        hardness = dict[sender.currentTitle!]!
        down=Float(hardness)
        
//        for i in stride(from: hardness, to: 0, by: -1){
//            print(i,"seconds")
//            sleep(1)
//        }
        
        // here this below timer just calls fireTimer after every "timerInterval" number of times.
        // like here it will call fireTimer after every 1 second
       timer=Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(fireTimer), userInfo: nil, repeats: true)
        
    }
    
    
    @objc func fireTimer(){
        if hardness > 0 {
            hardness-=1
            progress+=1
            progressBar.progress = Float(progress/down)
        }else{
            timer.invalidate()
            textView.text = "Done..!"
            playSound()
            
        }
    }
    func playSound() {
        let url = Bundle.main.url(forResource: "C", withExtension: "wav")
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()
                
    }
   
    
}
