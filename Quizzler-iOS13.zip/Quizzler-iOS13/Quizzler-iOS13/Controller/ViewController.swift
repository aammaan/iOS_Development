//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var abutton: UIButton!
    @IBOutlet weak var bButton: UIButton!
    
    @IBOutlet weak var cButton: UIButton!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    var quizBrain = QuizBrain()
    
    @IBOutlet weak var scoreCounter: UILabel!
    
//    let quizAnswer = [
//
//    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateUI()
        progressBar.progress=0.0
        
    }
    
    @IBAction func answerButton(_ sender: UIButton) {
        let userAnswer = sender.currentTitle!
        
        let userGotItRight = quizBrain.checkAnswer(userAnswer)
         
        if userGotItRight{
            sender.backgroundColor = UIColor.green
            
        }else{
            sender.backgroundColor = UIColor.red
            
        }
    
        
        quizBrain.nextQuestion()

        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector:#selector(updateUI), userInfo: nil, repeats: false)

        
        
//        updateUI()


    }
    @objc func updateUI(){
        questionLabel.text = quizBrain.getQuestionText()
        let ansChoice = quizBrain.getOption()
        abutton.setTitle(ansChoice[0], for:  .normal)
        bButton.setTitle(ansChoice[1], for:  .normal)
        cButton.setTitle(ansChoice[2], for:  .normal)
        
        scoreCounter.text="Score: " + String(quizBrain.getScore())
        progressBar.progress = quizBrain.getProgress()
        abutton.backgroundColor=UIColor.clear
        bButton.backgroundColor=UIColor.clear
        cButton.backgroundColor=UIColor.clear
    }
}

